# Question 1:
# Write a program to add a key and value to a dictionary.

# Sample Dictionary : {0: 10, 1: 20}
# Expected Result : {0: 10, 1: 20, 2: 30}

# Creating a dictionary with initial key-value pairs
dict_new = {
   0: 10,
   1: 20
}

# Adding a new key-value pair to the dictionary
dict_new[2] = 30
# Displaying the updated dictionary
print(dict_new)