# Question 1:
# Write a program to create a list of 5 integers and display the list items. Access individual elements through index.

# Creating a list of 5 integers
list_items = [111, 222, 333, 444, 555]

# Displaying the list items
print("The five elements in the list are as follows:")
for items in list_items:
   print(items)