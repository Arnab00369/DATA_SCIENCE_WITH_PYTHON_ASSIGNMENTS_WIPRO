# Question 2: Write a program to check if a given number is odd or even.

number = int(input("Enter a number = "))

print("\nOutput:")
if(number % 2 == 0):
   print(number," is an Even Number")
else:
   print(number," is an Odd Number")